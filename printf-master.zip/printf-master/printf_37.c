#include "holberton.h"
/**
 * printf_37 - prints the char 37.
 * Return: 1.
 */
int printf_37(void)
{
	_putchar(37);
	return (1);
}
